AR FF TOUR - Demo PWA

Open index.html in a modern browser, or host this folder on an HTTPS static host.

Features in this prototype:
- Tournament listing and registration
- Leaderboard demo
- Admin demo: create tournaments, edit app name, default entry fee, bKash/Nagad display numbers, notice, and upload logo/banner images
- Bangla / English interface toggle
- Local browser storage

IMPORTANT:
This is a front-end prototype only. Data is stored in the current browser/device and is NOT synced to other users. Admin controls are not protected by a secure server login. Do not use it to collect real payments or sensitive player data. Before public launch, connect a backend/database, secure server-side admin authentication, image storage, and an approved payment gateway. Never store payment PINs or OTPs.

This is a fan-made community project and is not affiliated with Garena.
